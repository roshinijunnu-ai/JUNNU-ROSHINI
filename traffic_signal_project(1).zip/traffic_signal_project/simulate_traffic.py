"""
simulate_traffic.py
Simulates vehicle counts over time and outputs a plot showing assigned green time.
"""
import numpy as np
import matplotlib.pyplot as plt

def decide_green_time(count, base=10, per_vehicle=1.5, max_time=60):
    t = base + per_vehicle * count
    return min(int(t), max_time)

np.random.seed(0)
counts = []
c = 5
for _ in range(60):
    c += np.random.randint(-2,3)
    c = max(0, c)
    counts.append(c)

green_times = [decide_green_time(cnt) for cnt in counts]

plt.figure(figsize=(8,3))
plt.plot(counts, label="Vehicle count")
plt.plot(green_times, label="Assigned green time (sec)")
plt.xlabel("Time step")
plt.legend()
plt.tight_layout()
plt.savefig("adaptive_green_time_plot.png")
print("Saved adaptive_green_time_plot.png")