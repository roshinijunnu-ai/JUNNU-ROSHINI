import streamlit as st
from pathlib import Path
from detector_controller import count_vehicles, decide_green_time
from PIL import Image
st.title("AI Traffic Signal Control — Demo")
st.write("Counts vehicles in synthetic frames and assigns green time.")
frames = sorted(Path(__file__).parent.glob("frame_*.png"))
choice = st.selectbox("Scenario", [p.name for p in frames])
img = Image.open(Path(__file__).parent / choice)
st.image(img, use_column_width=True)
count, boxes = count_vehicles(Path(__file__).parent / choice)
green = decide_green_time(count)
st.markdown(f"**Detected vehicles:** {count}")
st.markdown(f"**Assigned green time:** {green} seconds")
if st.button("Show detection overlay"):
    import cv2
    im = cv2.imread(str(Path(__file__).parent / choice))
    _, boxes = count_vehicles(Path(__file__).parent / choice)
    for (x,y,w,h) in boxes:
        cv2.rectangle(im, (x,y), (x+w,y+h), (0,255,0), 2)
    st.image(im[:,:,::-1], use_column_width=True)