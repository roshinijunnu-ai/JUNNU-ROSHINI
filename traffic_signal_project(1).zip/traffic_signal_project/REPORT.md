# AI Traffic Signal Control using Computer Vision

## Abstract
Prototype system that counts vehicles from camera frames and adapts traffic signal green time. Demo uses synthetic frames and a contour-based detector. Replace with YOLO for production.

## Files
- detector_controller.py
- simulate_traffic.py
- app_streamlit.py
- frame_low.png, frame_medium.png, frame_high.png
