"""
detector_controller.py
Counts vehicles in image frames using simple contour detection and computes adaptive green time.
Usage: python detector_controller.py <frames_folder>
"""
import cv2
import numpy as np
from pathlib import Path

def count_vehicles(img_path, min_area=500):
    img = cv2.imread(str(img_path))
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    _,th = cv2.threshold(gray, 60, 255, cv2.THRESH_BINARY_INV)
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5,5))
    th = cv2.morphologyEx(th, cv2.MORPH_OPEN, kernel, iterations=2)
    contours, _ = cv2.findContours(th, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    count = 0
    boxes = []
    for c in contours:
        area = cv2.contourArea(c)
        if area > min_area:
            x,y,w,h = cv2.boundingRect(c)
            boxes.append((x,y,w,h))
            count += 1
    return count, boxes

def decide_green_time(count, base=10, per_vehicle=1.5, max_time=60):
    t = base + per_vehicle * count
    return min(int(t), max_time)

if __name__ == "__main__":
    import argparse, os
    parser = argparse.ArgumentParser()
    parser.add_argument("frames_folder", help="Folder with PNG frames")
    args = parser.parse_args()
    folder = Path(args.frames_folder)
    for p in sorted(folder.glob("frame_*.png")):
        count, boxes = count_vehicles(p)
        green_time = decide_green_time(count)
        print(f"{p.name} -> vehicles: {count}, assigned_green_time: {green_time} sec")